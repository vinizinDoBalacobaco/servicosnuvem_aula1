<template>
  <div id="a">
    <ul class="chat-messages">
      <li v-for="(message, index) in messages" :key="index" :class="['chat-message', message.role + '-message']">
        {{ message.text }}
      </li>
    </ul>

    <input type="text" v-model="form.meuInput" @keyup.enter="sendMessage" placeholder="Digite sua mensagem...">
    <input type="button" value="Enviar" @click="sendMessage">
  </div>
</template>

<script>
import { GoogleGenerativeAI } from "@google/generative-ai";

export default {
  name: 'HelloWorld',
  data() {
    return {
      form: {
        meuInput: ""
      },
      messages: [], // Array to store messages
      genAI: null,
      model: null,
      generationConfig: {
        temperature: 1,
        topP: 0.95,
        topK: 64,
        maxOutputTokens: 8192,
        responseMimeType: "text/plain",
      }
    };
  },
  methods: {
    async sendMessage() {
      const apiKey = "AIzaSyA2IguhcKunUYQToJRvahkhLqrIU2X1Kig";
      this.genAI = new GoogleGenerativeAI(apiKey);
      this.model = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

      const chatSession = this.model.startChat({
        generationConfig: this.generationConfig
      });

      const result = await chatSession.sendMessage(this.form.meuInput);
      const responseText = result.response.text();

      // Add user message to messages array
      this.messages.push({ role: "user", text: this.form.meuInput });
      // Add bot response to messages array
      this.messages.push({ role: "bot", text: responseText });

      // Clear input after sending message
      this.form.meuInput = "";   
    }
  }
}
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}

#a {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
  align-items: center;
  min-height: 100vh;
  background-color: #f0f0f0;
}

input[type="text"], input[type="button"] {
  padding: 10px 20px;
  border: none;
  border-radius: 25px;
  cursor: pointer;
  font-size: 16px;
  font-weight: bold;
  text-transform: uppercase;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s, transform 0.2s ease-out;
}

input[type="button"] {
  background-color: #4CAF50;
  color: white;
}

input[type="button"]:hover {
  background-color: #ff008c;
  transform: scale(1.5);
}

input[type="button"]:active {
  transform: scale(0.5);
}

/* Estilos para mensagens do chat */
ul.chat-messages {
  margin-top: 20px;
  overflow-y: scroll;
  max-height: 600px; /* Ajuste conforme necessário */
  padding: 10px;
}

.chat-message {
  padding: 8px 12px;
  margin-bottom: 10px;
  border-radius: 20px;
  word-break: break-word;
}

.user-message {
  color: rgb(19, 43, 17);
  text-align: right;
  background-color: #3dd83db2; /* Cor de fundo para mensagens do usuário */
}

.bot-message {
  background-color: #65a4af94;
  text-align: left;
  color: #1d1224;
  font-style: italic;
}

/* Estilo adicional para destacar a resposta do bot */
.bot-message-text {
  color: #ff008c; /* Cor diferente para o texto da mensagem do bot */
}
</style>
